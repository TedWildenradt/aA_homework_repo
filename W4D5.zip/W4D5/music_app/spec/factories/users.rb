FactoryBot.define do
  factory :user do
    email "bob@example.com"
    password "password"
  end
end
